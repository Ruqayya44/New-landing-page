# AnytiGravity — Landing Page

A single-page architecture & interior design studio website. Pure HTML + CSS + JavaScript
(no frameworks, no build step, no dependencies).

---

## 1. Folder structure

```
anytigravity-site/
├── index.html              ← the page markup
├── assets/
│   ├── css/styles.css      ← all styling (design tokens at the top)
│   ├── js/main.js          ← all behaviour (carousel, gallery, form, menus…)
│   ├── img/                ← 10 photos (WebP)
│   └── video/hero-loop.mp4 ← hero showreel video
└── README.md
```

## 2. How to run it

**Option A — just open it**
Double-click `index.html`. Everything works offline.

**Option B — local server (recommended)**
```bash
# inside the anytigravity-site folder
python3 -m http.server 8080
# then open http://localhost:8080
```
or `npx serve .` / VS Code “Live Server” — any static server is fine.

**Option C — put it online**
Upload the whole folder to Netlify Drop, Vercel, GitHub Pages, cPanel or any
shared hosting `public_html`. No server-side code is required. Rename the folder
to whatever you like before uploading.

## 3. Sections on the page

| Section | Anchor | Notes |
|---|---|---|
| Header / nav (sticky, scroll-spy) | — | mobile hamburger under 900px |
| Hero + showreel video | `#home` | play/pause button, auto-pauses off-screen |
| Client logos (dummy) | — | swap for real client logos |
| What we do + 3 service cards | `#services` | |
| About the studio | `#about` | |
| **Our process** (4 steps) | `#process` | |
| **Explore Our Latest Projects** carousel | `#showcase` | infinite loop, drag/swipe, arrows, dots, autoplay, click = project preview |
| **Gallery** (masonry, filters, lightbox) | `#gallery` | images keep their own aspect ratio — nothing is cropped |
| Latest works (dark) | `#projects` | |
| Mission + animated counters | `#mission` | |
| Contact form | `#contact` | client-side validation + success state |
| Footer | — | CTA band, link columns, social icons |

## 4. Common edits

**Colours / fonts** — `assets/css/styles.css`, the `:root` block at the top
(`--cream`, `--ink`, `--accent`, `--max`, radii, shadows…).

**Project carousel items** — `assets/js/main.js`, the `PROJECTS` array near the top:
```js
var PROJECTS = [
  { title: "Modern Living Room", type: "Interior", loc: "New York, USA",
    img: "assets/img/cat-interiors.webp", size: "wide" },
  ...
];
```
Add or remove objects — the loop, dots and (3×) clones rebuild automatically.

**Gallery items** — `index.html`, inside `<div class="gg-grid" id="ggGrid">`.
Each item is:
```html
<figure class="gg-item" data-cat="interiors" data-title="Warm Minimal Living" data-label="Interior · New York">
  <img src="assets/img/cat-interiors.webp" alt="Warm minimal living room" loading="lazy" />
  ...
</figure>
```
`data-cat` must match one of the filter buttons (`architecture`, `interiors`,
`landscape`, `commercial`). The masonry uses CSS columns, so any image size fits
without cropping — no width/height needed.

**Images** — drop new files into `assets/img/` and point to them. Recommended:
WebP, 1000–1600 px wide.

**Hero video** — replace `assets/video/hero-loop.mp4` (keep the same name), and
update the `poster` attribute in `index.html` if you also change the still frame.
H.264 MP4, muted, 6–12 s loop works best.

**Contact form** — `assets/js/main.js`, look for `demo submit`:
```js
setTimeout(function () { … }, 1000);
```
Replace that block with a real `fetch()` to your endpoint (Formspree, Getform,
your own API, etc.). Current fields: name, email, phone, project type, budget,
location, message, consent.

**Phone / email / address** — placeholder values are `+91 98765 43210`,
`hello@anytigravity.com`, `14 Civil Lines, Kanpur`. Search & replace across
`index.html`.

## 5. Browser support & accessibility

- Modern evergreen browsers (Chrome, Edge, Safari, Firefox).
- Responsive: 1440 → 360 px, touch targets ≥ 44 px, mobile nav, stacked layouts.
- Keyboard: carousel arrows, gallery lightbox (`Esc`, `←` `→`), focusable buttons.
- Respects `prefers-reduced-motion` (animations off, video paused).

## 6. Content note

All photography and the hero video are **AI-generated placeholders** intended for
demo purposes — replace them with real project photos before going live.
The brand name, project names, client logos and contact details are dummy content.
