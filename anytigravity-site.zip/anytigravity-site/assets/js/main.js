(function () {
  "use strict";
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------------------------------------------------------
     1. PROJECT DATA  (change titles / locations / images here)
     --------------------------------------------------------- */
  var PROJECTS = [
    { title: "Modern Living Room", type: "Interior",  loc: "New York, USA",     img: "__IMG_INTERIORS__", size: "wide" },
    { title: "Luxury Villa",       type: "Residential", loc: "Los Angeles, USA", img: "__IMG_PROJ_VILLA__", size: "wide" },
    { title: "Creative Office Space", type: "Commercial", loc: "San Francisco, USA", img: "__IMG_OFFICE__", size: "wide" },
    { title: "Minimal Living",     type: "Interior",  loc: "Copenhagen, DK",   img: "__IMG_PROJ_MINIMAL__", size: "wide" },
    { title: "Outdoor Retreat",    type: "Landscape", loc: "Bali, Indonesia",  img: "__IMG_OUTDOOR__", size: "wide" },
    { title: "Coastal Residence",  type: "Architecture", loc: "Santorini, GR", img: "__IMG_ARCH__", size: "wide" },
    { title: "Green Retreat",      type: "Landscape", loc: "Kyoto, Japan",     img: "__IMG_PROJ_GREEN__", size: "wide" }
  ];

  var ARROW = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h13M12.5 6l6 6-6 6"/></svg>';
  var PIN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11z"/><circle cx="12" cy="10" r="2.4"/></svg>';

  /* ---------------------------------------------------------
     2. BUILD CAROUSEL CARDS
     --------------------------------------------------------- */
  var track = document.getElementById("cTrack");
  var dotsWrap = document.getElementById("cDots");
  var viewport = document.getElementById("cViewport");

  var N = PROJECTS.length;
  var COPIES = 3; /* card set is cloned 3x so the loop never shows an empty side */

  for (var c = 0; c < COPIES; c++) {
    PROJECTS.forEach(function (p, i) {
      var card = document.createElement("article");
      card.className = "c-card";
      card.dataset.size = p.size;
      card.dataset.p = i;
      card.setAttribute("aria-hidden", c === 1 ? "false" : "true");
      card.innerHTML =
        '<div class="shot">' +
          '<span class="type">' + p.type + '</span>' +
          '<img src="' + p.img + '" alt="' + p.title + ' in ' + p.loc + '" loading="lazy" draggable="false">' +
        '</div>' +
        '<div class="body">' +
          '<div><h3>' + p.title + '</h3><div class="loc">' + PIN + '<span>' + p.loc + '</span></div></div>' +
          '<span class="go">' + ARROW + '</span>' +
        '</div>';
      track.appendChild(card);
    });
  }

  PROJECTS.forEach(function (p, i) {
    var dot = document.createElement("button");
    dot.type = "button";
    dot.setAttribute("role", "tab");
    dot.setAttribute("aria-label", "Go to " + p.title);
    dot.addEventListener("click", function () { goToDot(i); restart(); });
    dotsWrap.appendChild(dot);
  });

  var cards = Array.prototype.slice.call(track.children);
  var dots = Array.prototype.slice.call(dotsWrap.children);

  /* ---------------------------------------------------------
     3. CAROUSEL ENGINE (centre-focus, scale by distance)
     --------------------------------------------------------- */
  var index = N; /* start on the middle copy */
  var step = 0, cardW = 0, viewW = 0;

  function measure() {
    var cs = getComputedStyle(track);
    var gap = parseFloat(cs.columnGap || cs.gap) || 20;
    cardW = cards[0].getBoundingClientRect().width;
    step = cardW + gap;
    viewW = viewport.clientWidth;
  }

  function place() {
    var offset = viewW / 2 - (index * step + cardW / 2);
    track.style.transform = "translate3d(" + offset + "px,0,0)";
  }

  function render(animate) {
    if (animate === false) track.style.transition = "none";
    place();

    var active = ((index % N) + N) % N;

    cards.forEach(function (c, i) {
      var d = Math.abs(i - index);
      var scale = i === index ? 1 : Math.max(0.83, 1 - d * 0.085);
      c.style.setProperty("--s", scale.toFixed(3));
      c.classList.toggle("is-active", i === index);
      c.style.opacity = d > 2 ? 0.32 : 1;
      c.setAttribute("aria-hidden", d > 2 ? "true" : "false");
    });
    dots.forEach(function (d, i) {
      var on = i === active;
      d.classList.toggle("on", on);
      d.setAttribute("aria-selected", on ? "true" : "false");
    });

    if (animate === false) {
      void track.offsetWidth; /* reflow so the reset isn't animated */
      track.style.transition = "";
    }
  }

  /* keep the centre card inside the middle copy so the loop is seamless */
  function normalise() {
    if (index < N || index >= 2 * N) {
      index = N + (((index % N) + N) % N);
      render(false); /* silently re-centre on the identical card in the middle copy */
    }
  }
  track.addEventListener("transitionend", function (e) {
    if (e.propertyName === "transform") { normalise(); }
  });

  function goTo(i, animate) {
    index = i;
    render(animate);
    if (animate === false) { normalise(); }
  }

  function goToDot(d) {
    var current = ((index % N) + N) % N;
    var delta = d - current;
    if (delta > N / 2) { delta -= N; }
    if (delta < -N / 2) { delta += N; }
    goTo(index + delta);
  }

  function next() { goTo(index + 1); }
  function prev() { goTo(index - 1); }

  document.getElementById("cNext").addEventListener("click", function () { next(); restart(); });
  document.getElementById("cPrev").addEventListener("click", function () { prev(); restart(); });

  var resizeTimer;
  window.addEventListener("resize", function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () { measure(); render(false); }, 120);
  });

  /* --- drag / swipe --- */
  var dragging = false, startX = 0, delta = 0, moved = false;

  function pointerDown(e) {
    dragging = true; moved = false; startX = (e.touches ? e.touches[0].clientX : e.clientX); delta = 0;
    track.style.transition = "none";
    pause();
  }
  function pointerMove(e) {
    if (!dragging) return;
    var x = (e.touches ? e.touches[0].clientX : e.clientX);
    delta = x - startX;
    if (Math.abs(delta) > 6) moved = true;
    var offset = viewW / 2 - (index * step + cardW / 2) + delta;
    track.style.transform = "translate3d(" + offset + "px,0,0)";
  }
  function pointerUp() {
    if (!dragging) return;
    dragging = false;
    track.style.transition = "";
    if (Math.abs(delta) > Math.min(90, cardW * 0.22)) {
      if (delta < 0) { goTo(index + 1); } else { goTo(index - 1); }
    } else {
      render();
    }
    delta = 0;
    setTimeout(function () { moved = false; }, 20);
    restart();
  }

  viewport.addEventListener("mousedown", function (e) { e.preventDefault(); pointerDown(e); });
  window.addEventListener("mousemove", pointerMove);
  window.addEventListener("mouseup", pointerUp);
  viewport.addEventListener("touchstart", pointerDown, { passive: true });
  viewport.addEventListener("touchmove", pointerMove, { passive: true });
  viewport.addEventListener("touchend", pointerUp);
  viewport.addEventListener("dragstart", function (e) { e.preventDefault(); });

  /* --- keyboard --- */
  document.addEventListener("keydown", function (e) {
    if (document.querySelector(".lb.open")) return; /* lightbox owns the keys */
    if (e.key === "ArrowRight") { next(); restart(); }
    if (e.key === "ArrowLeft") { prev(); restart(); }
  });

  /* --- autoplay --- */
  var timer = null;
  function play() {
    if (reduce) return;
    stop();
    timer = setInterval(function () { goTo(index + 1); }, 5200);
  }
  function stop() { if (timer) { clearInterval(timer); timer = null; } }
  function restart() { stop(); play(); }
  function pause() { stop(); }

  var carouselEl = document.getElementById("carousel");
  carouselEl.addEventListener("mouseenter", stop);
  carouselEl.addEventListener("mouseleave", play);
  carouselEl.addEventListener("focusin", stop);
  carouselEl.addEventListener("focusout", play);
  document.addEventListener("visibilitychange", function () {
    document.hidden ? stop() : play();
  });

  /* init */
  function boot() { measure(); render(false); play(); }
  if (document.readyState === "complete") { boot(); }
  else { window.addEventListener("load", boot); }
  window.addEventListener("resize", function () { setTimeout(boot, 160); }, { once: true });

  /* ---------------------------------------------------------
     4. SCROLL REVEAL
     --------------------------------------------------------- */
  var revealEls = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -8% 0px" });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("in"); });
  }

  /* ---------------------------------------------------------
     5. COUNTERS
     --------------------------------------------------------- */
  function animateCount(el) {
    var target = parseFloat(el.dataset.to), dur = 1400, t0 = null;
    if (reduce) { el.textContent = target; return; }
    function tick(ts) {
      if (!t0) t0 = ts;
      var p = Math.min(1, (ts - t0) / dur);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(target * eased);
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  var statsEl = document.getElementById("stats");
  if (statsEl && "IntersectionObserver" in window) {
    var so = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          statsEl.querySelectorAll(".count").forEach(animateCount);
          so.disconnect();
        }
      });
    }, { threshold: 0.4 });
    so.observe(statsEl);
  }

  /* ---------------------------------------------------------
     6. HEADER: progress bar, stuck state, menu, scrollspy
     --------------------------------------------------------- */
  var head = document.getElementById("siteHead");
  var bar = document.getElementById("progressBar");
  var toTop = document.getElementById("toTop");
  var sections = Array.prototype.slice.call(document.querySelectorAll("section[id], footer[id]"));
  var navLinks = Array.prototype.slice.call(document.querySelectorAll(".nav a"));

  function onScroll() {
    var y = window.scrollY || document.documentElement.scrollTop;
    var h = document.documentElement.scrollHeight - window.innerHeight;
    bar.style.width = (h > 0 ? Math.min(100, (y / h) * 100) : 0) + "%";
    head.classList.toggle("stuck", y > 12);
    toTop.classList.toggle("show", y > 620);

    var current = sections[0];
    sections.forEach(function (s) {
      if (s.offsetTop - 120 <= y) current = s;
    });
    if (current) {
      navLinks.forEach(function (a) {
        a.classList.toggle("active", a.getAttribute("href") === "#" + current.id);
      });
    }
  }
  var scrollTick = false;
  window.addEventListener("scroll", function () {
    if (!scrollTick) {
      scrollTick = true;
      requestAnimationFrame(function () { onScroll(); scrollTick = false; });
    }
  }, { passive: true });
  onScroll();

  toTop.addEventListener("click", function () {
    window.scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" });
  });

  var burger = document.getElementById("burger");
  var nav = document.getElementById("nav");
  burger.addEventListener("click", function () {
    var open = nav.classList.toggle("open");
    burger.classList.toggle("open", open);
    burger.setAttribute("aria-expanded", open ? "true" : "false");
  });
  nav.querySelectorAll("a").forEach(function (a) {
    a.addEventListener("click", function () {
      nav.classList.remove("open");
      burger.classList.remove("open");
      burger.setAttribute("aria-expanded", "false");
    });
  });


  /* ---------------------------------------------------------
     8. CONTACT FORM — validation + demo submit
     --------------------------------------------------------- */
  var form = document.getElementById("projectForm");
  if (form) {
    var fName = document.getElementById("fname"),
        fEmail = document.getElementById("femail"),
        fPhone = document.getElementById("fphone"),
        fType = document.getElementById("ftype"),
        fMsg = document.getElementById("fmsg"),
        fConsent = document.getElementById("fconsent"),
        fConsentWrap = document.getElementById("fconsentWrap"),
        fCount = document.getElementById("fmsgCount"),
        fBtn = document.getElementById("fsubmit");

    var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/;

    function fieldOf(el) { return el.closest(".field"); }
    function mark(el, bad) { fieldOf(el).classList.toggle("invalid", !!bad); }

    function checkName()  { var v = fName.value.trim();  var bad = v.length < 2;              mark(fName, bad);  return !bad; }
    function checkEmail() { var v = fEmail.value.trim(); var bad = !EMAIL_RE.test(v);          mark(fEmail, bad); return !bad; }
    function checkPhone() {
      var digits = fPhone.value.replace(/\D/g, "");
      var bad = fPhone.value.trim().length > 0 && (digits.length < 7 || digits.length > 15);
      mark(fPhone, bad); return !bad;
    }
    function checkType()  { var bad = fType.value === ""; mark(fType, bad); return !bad; }
    function checkMsg()   { var v = fMsg.value.trim();   var bad = v.length < 10;              mark(fMsg, bad);  return !bad; }
    function checkConsent() {
      var bad = !fConsent.checked;
      fConsentWrap.classList.toggle("invalid", bad);
      return !bad;
    }

    /* live validation: clear the error as soon as the field is fixed */
    fName.addEventListener("blur", checkName);
    fEmail.addEventListener("blur", checkEmail);
    fPhone.addEventListener("blur", checkPhone);
    fMsg.addEventListener("blur", checkMsg);
    fName.addEventListener("input", function () { if (fieldOf(fName).classList.contains("invalid")) checkName(); });
    fEmail.addEventListener("input", function () { if (fieldOf(fEmail).classList.contains("invalid")) checkEmail(); });
    fPhone.addEventListener("input", function () { if (fieldOf(fPhone).classList.contains("invalid")) checkPhone(); });
    fMsg.addEventListener("input", function () {
      fCount.textContent = fMsg.value.length + " / 600";
      if (fieldOf(fMsg).classList.contains("invalid")) checkMsg();
    });
    fType.addEventListener("change", function () { if (fieldOf(fType).classList.contains("invalid")) checkType(); });
    fConsent.addEventListener("change", function () {
      if (fConsent.checked) fConsentWrap.classList.remove("invalid");
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var results = [checkName(), checkEmail(), checkPhone(), checkType(), checkMsg(), checkConsent()];
      var firstBad = form.querySelector(".field.invalid input, .field.invalid select, .field.invalid textarea");
      if (results.indexOf(false) !== -1) {
        if (firstBad) firstBad.focus({ preventScroll: false });
        return;
      }

      /* demo submit — hook this up to your API / Formspree endpoint */
      fBtn.classList.add("loading");
      fBtn.disabled = true;
      fBtn.querySelector(".label").textContent = "Sending…";

      setTimeout(function () {
        fBtn.classList.remove("loading");
        fBtn.disabled = false;
        fBtn.querySelector(".label").textContent = "Send Enquiry";
        form.classList.add("sent");
        form.reset();
        fCount.textContent = "0 / 600";
        ["invalid"].forEach(function (c) {
          form.querySelectorAll("." + c).forEach(function (el) { el.classList.remove(c); });
        });
      }, 1000);
    });

    document.getElementById("fagain").addEventListener("click", function () {
      form.classList.remove("sent");
      fName.focus();
    });
  }


  /* ---------------------------------------------------------
     9. HERO SHOWREEL — play / pause
     --------------------------------------------------------- */
  var heroVideo = document.getElementById("heroVideo");
  var vidToggle = document.getElementById("vidToggle");
  if (heroVideo && vidToggle) {
    function syncVidBtn() {
      var paused = heroVideo.paused;
      vidToggle.classList.toggle("paused", paused);
      vidToggle.setAttribute("aria-pressed", paused ? "true" : "false");
      vidToggle.setAttribute("aria-label", paused ? "Play showreel" : "Pause showreel");
    }
    if (reduce) { heroVideo.pause(); }
    heroVideo.addEventListener("play", syncVidBtn);
    heroVideo.addEventListener("pause", syncVidBtn);
    vidToggle.addEventListener("click", function () {
      if (heroVideo.paused) { heroVideo.play(); } else { heroVideo.pause(); }
    });
    /* don't burn CPU when the hero is off screen */
    if ("IntersectionObserver" in window) {
      new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting && !reduce) { heroVideo.play().catch(function () {}); }
          else if (!en.isIntersecting) { heroVideo.pause(); }
        });
      }, { threshold: 0.15 }).observe(heroVideo);
    }
    syncVidBtn();
  }

  /* ---------------------------------------------------------
     10. GALLERY — filters + lightbox
     --------------------------------------------------------- */
  var ggGrid = document.getElementById("ggGrid");
  if (ggGrid) {
    var ggItems = Array.prototype.slice.call(ggGrid.children);
    var ggFilters = document.getElementById("ggFilters");
    var visible = ggItems.slice();
    var lbIndex = 0;

    /* ---- lightbox shell (built once, reused) ---- */
    var lb = document.createElement("div");
    lb.className = "lb";
    lb.innerHTML =
      '<button class="lb-close" aria-label="Close gallery"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button>' +
      '<button class="lb-nav lb-prev" aria-label="Previous image"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H6M11.5 18l-6-6 6-6"/></svg></button>' +
      '<button class="lb-nav lb-next" aria-label="Next image"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h13M12.5 6l6 6-6 6"/></svg></button>' +
      '<figure><img alt=""><figcaption><span><b></b><small></small></span><span class="lb-count"></span></figcaption></figure>';
    document.body.appendChild(lb);
    var lbImg = lb.querySelector("img"),
        lbTitle = lb.querySelector("b"),
        lbLabel = lb.querySelector("small"),
        lbCount = lb.querySelector(".lb-count");

    function paintLb() {
      var fig = visible[lbIndex];
      if (!fig) return;
      var img = fig.querySelector("img");
      lbImg.src = img.src;
      lbImg.alt = img.alt;
      lbTitle.textContent = fig.dataset.title;
      lbLabel.textContent = fig.dataset.label;
      lbCount.textContent = (lbIndex + 1) + " / " + visible.length;
    }
    function openLb(i) {
      lbIndex = i;
      paintLb();
      lb.classList.add("open");
      document.body.style.overflow = "hidden";
    }
    function closeLb() {
      lb.classList.remove("open");
      document.body.style.overflow = "";
    }
    function stepLb(d) {
      lbIndex = (lbIndex + d + visible.length) % visible.length;
      paintLb();
    }

    ggGrid.addEventListener("click", function (e) {
      var fig = e.target.closest(".gg-item");
      if (!fig) return;
      var i = visible.indexOf(fig);
      if (i > -1) openLb(i);
    });
    lb.querySelector(".lb-close").addEventListener("click", closeLb);
    lb.querySelector(".lb-prev").addEventListener("click", function () { stepLb(-1); });
    lb.querySelector(".lb-next").addEventListener("click", function () { stepLb(1); });
    lb.addEventListener("click", function (e) { if (e.target === lb) closeLb(); });
    document.addEventListener("keydown", function (e) {
      if (!lb.classList.contains("open")) return;
      if (e.key === "Escape") closeLb();
      if (e.key === "ArrowRight") stepLb(1);
      if (e.key === "ArrowLeft") stepLb(-1);
    });

    /* ---- category filters ---- */
    ggFilters.addEventListener("click", function (e) {
      var btn = e.target.closest("button[data-filter]");
      if (!btn) return;
      Array.prototype.forEach.call(ggFilters.children, function (b) {
        b.classList.toggle("on", b === btn);
      });
      var f = btn.dataset.filter;
      ggItems.forEach(function (it) {
        it.classList.toggle("hide", f !== "all" && it.dataset.cat !== f);
      });
      visible = ggItems.filter(function (it) { return !it.classList.contains("hide"); });
      visible.forEach(function (it, i) {
        it.style.animation = "none";
        void it.offsetWidth;
        it.style.animation = "ggIn .5s cubic-bezier(.22,1,.36,1) both";
        it.style.animationDelay = (i * 45) + "ms";
      });
    });
  }

  /* ---------------------------------------------------------
     11. SMALL DETAILS
     --------------------------------------------------------- */
  document.getElementById("year").textContent = new Date().getFullYear();

  /* clicking a project card opens a lightweight preview overlay */
  var overlay;
  function openPreview(p) {
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.style.cssText =
        "position:fixed;inset:0;z-index:200;display:grid;place-items:center;padding:24px;" +
        "background:rgba(16,12,8,.72);backdrop-filter:blur(6px);opacity:0;transition:opacity .35s ease";
      overlay.innerHTML =
        '<div style="max-width:820px;width:100%;background:#fdf9f3;border-radius:22px;overflow:hidden;' +
        'box-shadow:0 50px 100px -40px rgba(0,0,0,.6);transform:translateY(14px);transition:transform .45s cubic-bezier(.22,1,.36,1)}">' +
          '<div style="position:relative"><img id="pvImg" style="width:100%;height:min(56vh,420px);object-fit:cover;display:block">' +
          '<button id="pvClose" aria-label="Close preview" style="position:absolute;top:12px;right:12px;width:38px;height:38px;' +
          'border-radius:50%;background:rgba(255,253,250,.92);display:grid;place-items:center;font-size:20px;line-height:1;color:#15120f">&times;</button></div>' +
          '<div style="padding:22px 26px 26px"><span id="pvType" style="font-size:11px;letter-spacing:.22em;text-transform:uppercase;color:#9b6234;font-weight:700"></span>' +
          '<h3 id="pvTitle" style="margin:8px 0 6px;font-size:24px;letter-spacing:-.03em;color:#15120f"></h3>' +
          '<p id="pvLoc" style="color:#6f665e;font-size:14px;margin:0 0 18px"></p>' +
          '<a href="#contact" id="pvCta" style="display:inline-flex;align-items:center;gap:.6em;background:#15120f;color:#fdf9f3;' +
          'padding:12px 20px;border-radius:999px;font-size:14px;font-weight:600">Enquire about this project &rarr;</a></div>' +
        '</div>';
      document.body.appendChild(overlay);
      overlay.addEventListener("click", function (e) {
        if (e.target === overlay || e.target.id === "pvClose") closePreview();
      });
      document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") closePreview();
      });
    }
    overlay.querySelector("#pvImg").src = p.img;
    overlay.querySelector("#pvType").textContent = p.type + " · Project";
    overlay.querySelector("#pvTitle").textContent = p.title;
    overlay.querySelector("#pvLoc").textContent = p.loc;
    overlay.querySelector("#pvCta").onclick = closePreview;
    overlay.style.display = "grid";
    requestAnimationFrame(function () {
      overlay.style.opacity = "1";
      overlay.firstElementChild.style.transform = "none";
      document.body.style.overflow = "hidden";
    });
  }
  function closePreview() {
    if (!overlay) return;
    overlay.style.opacity = "0";
    overlay.firstElementChild.style.transform = "translateY(14px)";
    document.body.style.overflow = "";
    setTimeout(function () { overlay.style.display = "none"; }, 340);
  }

  track.addEventListener("click", function (e) {
    var card = e.target.closest(".c-card");
    if (!card || moved) return;
    var i = cards.indexOf(card);
    if (i !== index) { goTo(i); restart(); return; }
    openPreview(PROJECTS[parseInt(card.dataset.p, 10)]);
  });
})();
